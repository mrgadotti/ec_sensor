# DFRobot Gravity Analog Electrical Conductivity Sensor

This is a repository for DFRobot Gravity Analog Electrical Conductivity Sensor (EC meter)

It includes sample code for the EC meter calibration.

#[Youtube Video Tutorial](https://www.youtube.com/watch?v=SfYD8JZ1wK4&feature=youtu.be)
#[Product Link](https://www.dfrobot.com/index.php?route=product/product&search=DFR0300&description=true&product_id=1123)
