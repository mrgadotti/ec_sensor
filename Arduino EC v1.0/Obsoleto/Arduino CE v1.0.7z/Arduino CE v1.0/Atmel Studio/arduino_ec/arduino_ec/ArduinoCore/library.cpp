/*
 * ArduinoCore.cpp
 *
 * Created: 09/05/2017 09:42:52
 * Author : marce
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

